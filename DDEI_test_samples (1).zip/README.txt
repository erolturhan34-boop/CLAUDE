DDEI YARA Test Samples - BENIGN (zararsiz)
===========================================
Hicbiri zararli degildir; her biri yalnizca kendini tanitan bir metin
gosterir/yazar. Payload, komut calistirma, indirme YOKTUR.
Amac: DDEI YARA kurallarinin ilgili DOSYA TIPINI yakalayip yakalamadigini test etmek.

Dosya            Tip          Eslesen kural (YARA 3.10.0 ile test edildi)
---------------  -----------  --------------------------------------------
sample.elf       ELF          Detect_ELF_Executable
sample.exe       PE EXE       IsEXE
sample.jar       JAR          IsJAR
sample.macho     Mach-O       Detect_MachO_Binary
sample.dmg       DMG          Detect_Apple_DMG
sample.lnk       LNK          (kural yoksa eslesmez)
sample.zip       ZIP          (bu sette ZIP kurali yok - kendi kuralinla test et)
sample.py        Python       Detect_Shell_Script'e takilir (shebang /usr/bin/env)
sample.ps1       PowerShell   (kural yoksa eslesmez)
sample.bat       Batch        (kural yoksa eslesmez)
sample.cmd       Batch        (kural yoksa eslesmez)
sample.hta       HTA          (kural yoksa eslesmez)
sample.class     Java CLASS   (kural yoksa eslesmez)
sample.js        JScript      zararsiz - davranis kurali tetiklenmez
